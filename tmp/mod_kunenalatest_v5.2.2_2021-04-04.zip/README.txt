
Kunena Latest Module README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Latest 5.2.2!

INTRODUCTION
============

Kunena Latest Module enables your site visitors to see latest posts or messages from a forum.

Requirements: Joomla 2.5, Kunena Forum 2.0

END OF README
=============
